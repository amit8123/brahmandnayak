<!DOCTYPE html>
<html lang="en" dir="ltr" xml:lang="en-MR">

<head>
    <?php echo $__env->make('layouts.frontend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('layouts.frontend.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('page-content'); ?>
    <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- partial:partia/__scripts.html -->
        
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery-3.4.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/imagesloaded.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.countdown.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.zoom.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.inview.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/jquery.event.move.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/isotope.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/slick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/js/plugins/ion.rangeSlider.min.js')); ?>"></script>

        <script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>?v=2"></script>
        <script src="<?php echo e(asset('assets/frontend/js/divine.js')); ?>?v=2"></script>

        <!-- partial -->
    

    
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH /home4/csismxq9/brahmandnayak.org/resources/views/layouts/frontend/master.blade.php ENDPATH**/ ?>