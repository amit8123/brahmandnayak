<!DOCTYPE html>
<html>
    <head>
        <?php echo $__env->make('layouts.backend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
    <body class="admin-body">
        <?php echo $__env->make('layouts.backend.navigation.admin-navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('page-content'); ?>

            </div><!-- /admin-content -->
            <footer class="admin-footer">
                &copy; <?php echo e(date('Y')); ?> BSSSP Mandir Trust &middot; Developed by
                <a href="http://ashhwa.in/" target="_blank">Ashhwa Enterprises</a>
            </footer>
        </div><!-- /admin-main -->

        <?php echo $__env->make('layouts.backend.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            document.getElementById('sidebar-toggle').addEventListener('click', function () {
                document.getElementById('admin-sidebar').classList.toggle('open');
            });
        </script>
    </body>
    <?php else: ?>
    <body class="login-body">
        <?php echo $__env->yieldContent('page-content'); ?>

        <?php echo $__env->make('layouts.backend.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
    <?php endif; ?>
</html>
<?php /**PATH /home4/csismxq9/brahmandnayak.org/resources/views/layouts/backend/master.blade.php ENDPATH**/ ?>