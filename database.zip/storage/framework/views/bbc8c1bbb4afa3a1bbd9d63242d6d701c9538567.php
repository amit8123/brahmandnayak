<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset("assets/frontend/images/favicon/favicon.ico")); ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset("assets/frontend/images/favicon/favicon.ico")); ?>">
<meta charset="utf-8">
<!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame -->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<!-- Csrf Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<!--  Mobile Viewport Fix -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<!-- Website meta data -->
<meta content="File Manager" name="description">
<meta content="Tejas" name="author">
<!-- Raleway font -->
<link href="https://fonts.googleapis.com/css?family=Raleway:400,600,700" rel="stylesheet">
<title>
    <?php echo $__env->yieldContent('title'); ?>
</title>

<?php echo $__env->make('layouts.backend.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/csismxq9/brahmandnayak.org/resources/views/layouts/backend/head.blade.php ENDPATH**/ ?>