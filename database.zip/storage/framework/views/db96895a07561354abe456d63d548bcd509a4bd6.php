

<?php $__env->startSection('title'); ?>
मुख्य पान
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords', 'मुख्य पान, उपक्रम, निवेदन, कार्यक्रम, फेसबुक, ट्विटर, home, upkram, nivedan, information, facebook, twitter'); ?>

<?php $__env->startSection('description'); ?>
<?php $__currentLoopData = $upkramList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($item->title); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $trusty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($item->title); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<?php if($slider->isNotEmpty()): ?>
    
    <link rel="preload" as="image" href="<?php echo e(asset('assets/backend/images/slider_images/'.$slider->first()->image_path)); ?>" fetchpriority="high" />
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page-content'); ?>
        <!-- Banner Start -->
        <div class="sigma_banner banner-3">
            <div class="sigma_banner-slider">
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Banner Item Start -->
                <div class="light-bg sigma_banner-slider-inner bg-cover bg-center bg-norepeat" style="background-image: url('<?php echo e(asset('assets/backend/images/slider_images/'.$item->image_path)); ?>')"></div>
                <!-- Banner Item End -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- Banner End -->

        <!-- About Start -->
        <section class="section">
            <div class="container">
                <div id="nivedan" class="row align-items-center">
                    <div class="col-lg-6 mb-4 mb-lg-0">
                        <div class="dv-collage">
                            <figure class="dv-collage-main">
                                <img src="<?php echo e(asset('assets/frontend/images/about-group1/10.jpg')); ?>" alt="श्री दत्त" loading="lazy" />
                            </figure>
                            <figure class="dv-collage-side">
                                <img src="<?php echo e(asset('assets/frontend/images/about-group1/30.jpg')); ?>" alt="श्री स्वामी समर्थ" loading="lazy" />
                            </figure>
                            <figure class="dv-collage-side">
                                <img src="<?php echo e(asset('assets/frontend/images/about-group1/20.jpg')); ?>" alt="श्री नृसिंह सरस्वती" loading="lazy" />
                            </figure>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="dv-scroll" style="background-image: url('<?php echo e(asset('assets/frontend/images/QR/page1.png')); ?>')">
                            <h3 class="dv-scroll-title">निवेदन</h3>
                            <p>
                                नमस्कार, या संकेतस्थळावरील माहिती आणि छायाचित्रे ही पारंपारिक,
                                संगणकीय माहिती मायाजालात असलेल्या विविध संकेत स्थळे आणि
                                आधुनिक युगातील व्हाट्सअपच्या माध्यमातून एकत्रित करण्यात आली आहे.
                                बिनचूक माहिती देण्याचा आम्ही प्रयत्न करीत आहे. वेळोवेळी नवीन
                                माहिती यात समाविष्ट करण्याचा मानस आहे. या संकेतस्थळावरील कोणत्याही
                                माहितीबद्दल आपल्या सूचनांचे कायमच स्वागत राहील.
                                चूक भूल द्यावी घ्यावी ही विनंती.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr />
        <!-- vishwasta mandal start -->
        <section class="section">
            <div class="container">
                <div class="row align-items-top align-items-md-start">
                    <div id="vishwastal mandal" class="col-lg-6">
                        <div class="text-bg-primary card" style="max-width: 500px">
                            <div class="card-header fw-bold fs-5">विश्वस्त मंडळ</div>
                            <div class="card-body">
                                <ul class="card-body" style="list-style-type: disc">
                                <?php $__currentLoopData = $trusty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="text-bg-primary card" style="max-width: 500px">
                            <div class="card-header fw-bold fs-5">संयुक्त व्यवस्थापक</div>
                            <div class="card-body">
                                <ul class="card-body" style="list-style-type: disc">
                                <?php $__currentLoopData = $manager; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <br />
                <p>श्री स्वामी समर्थ संप्रदायाच्या प्रासादिक भक्तीचा प्रसार करण्यासाठी आणि संतसज्जनांच्या परंपरेला अनुसरून 'जनसेवा हीच ईश्वरसेवा' ह्या प्रेरणेने भक्तिमार्गातून सुविचार आणि शिकवण ह्याचा प्रचार करण्यासाठी ‘ब्रह्मांडनायक श्री स्वामी समर्थ प्रतिष्ठान’ विश्वस्त मंडळ कटिबद्ध आहे. ह्या विश्वस्त मंडळाचे सर्व सभासद सर्वतोपरी स्वामींच्या निस्सिम सेवेत आहेत.</p>
            </div>
        </section>
        <!-- vishwasta mandal end -->

         <!-- Form Start -->
        <div class="section dark-overlay bg-cover bg-center bg-norepeat" style="background-image: url('<?php echo e(asset('assets/frontend/images/bg2visit.jpg')); ?>')">
            <div class="container text-center">
                <h1 class="title">Visit Our Gallery</h1>
                <br />
                <a class="sigma_btn-custom" href="<?php echo e(route('gallery')); ?>">GALLERY</a>
            </div>
        </div>
        <!-- Form End -->
        <!-- About End -->


        

        
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\temple\resources\views/layouts/frontend/pages/home.blade.php ENDPATH**/ ?>