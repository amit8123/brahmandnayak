<?php $__env->startSection('sub-title'); ?>
    Slider - Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-custom-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-custom-scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="main-container container">
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8 col-sm-12">
                <?php echo $__env->make('layouts.backend.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class="form-horizontal" method="POST" action="<?php echo e(route('admin.slider.store')); ?>" enctype="multipart/form-data">
                    <div class="card text-white bg-dark mb-3">
                        <div class="card-header">
                            <h2 class="m-0">Create New Slider</h2>
                        </div>
                        <div class="card-body">
                            <?php echo e(csrf_field()); ?>

                            <!-- title -->
                            <div class="form-group">
                                <label class="col-form-label" for="title">Title</label>
                                <input type="text" name="title" class="form-control" id="title" value="<?php echo e(old('title')); ?>"
                                    required autofocus>
                            </div>
                            <!-- /title -->
                            <!-- image -->
                            <div class="form-group mb-0">
                                <label class="col-form-label" for="slider-image">Image</label> 
                                <input type="file" name="slider-image" class="form-control" id="slider-image">
                            </div>
                            <!-- /image -->
                        </div>
                        <div class="card-footer">
                            <div class="row">
                                <div class="col">
                                    <!-- submit -->
                                    <button type="submit" class="btn btn-block btn-success">Create</button>
                                    <!-- /submit -->
                                </div>
                                <div class="col">
                                    <!-- submit -->
                                    <a href="<?php echo e(route('admin.slider.index')); ?>" class="btn btn-block btn-danger">Cancel</a>
                                    <!-- /submit -->
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.pages.admin.injector.admin-attribute-injection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\temple\resources\views/layouts/backend/pages/admin/slider/create.blade.php ENDPATH**/ ?>