<!-- Scripts -->
<script type="text/javascript" src="<?php echo e(asset("assets/backend/js/jquery.min.js")); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset("assets/backend/js/bootstrap.bundle.min.js")); ?>"></script>
<script type="text/javascript" src="https://momentjs.com/downloads/moment-with-locales.js"></script>
<script>
    $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
        if (!$(this).next().hasClass('show')) {
            $(this).parents('.dropdown-menu').first().find('.show').removeClass('show');
        }
        var $subMenu = $(this).next('.dropdown-menu');
        $subMenu.toggleClass('show');


        $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
            $('.dropdown-submenu .show').removeClass('show');
        });

        return false;
    });

</script>
    
<!-- Custom scripts -->
<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH /home4/csismxq9/brahmandnayak.org/resources/views/layouts/backend/scripts.blade.php ENDPATH**/ ?>