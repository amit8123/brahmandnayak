<?php $__env->startSection('title'); ?>
    BSSSP - Admin | <?php echo $__env->yieldContent('sub-title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/css/datatables.min.css')); ?>">
    <style type="text/css">
        .main-container {
            padding-top: 0;
        }

        .word-break {
            word-break: break-all;
            word-break: break-word;
        }

        .word-overflow{
            white-space: nowrap;
            max-width: 150px;
            text-overflow: ellipsis;
            overflow: hidden;
        }
    </style>
    <?php echo $__env->yieldContent('sub-custom-styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset("assets/backend/js/datatables.min.js")); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.alert').delay(1000).fadeOut(2000);
        })
    </script>
    <?php echo $__env->yieldContent('sub-custom-scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\temple\resources\views/layouts/backend/pages/admin/injector/admin-attribute-injection.blade.php ENDPATH**/ ?>