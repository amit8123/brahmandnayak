<?php $__env->startSection('sub-title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
<div class="main-container">
    <?php echo $__env->make('layouts.backend.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- welcome -->
    <div class="welcome-banner">
        <h2>Namaste, <?php echo e(Auth::user()->name); ?> 🙏</h2>
        <p>Welcome to the temple admin panel. Use the menu on the left or the quick buttons below to manage your website.</p>
    </div>

    <!-- counts -->
    <h3 class="section-title">Overview</h3>
    <div class="stat-grid">
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="stat-card" href="<?php echo e(route($s['route'])); ?>">
                <span class="stat-icon" style="background: <?php echo e($s['color']); ?>"><i class="fas <?php echo e($s['icon']); ?>"></i></span>
                <span>
                    <span class="stat-num d-block"><?php echo e($s['count']); ?></span>
                    <span class="stat-text d-block"><?php echo e($s['label']); ?></span>
                    <span class="stat-link">View all &rarr;</span>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- quick actions -->
    <h3 class="section-title">Quick Actions</h3>
    <div class="quick-grid">
        <a class="quick-btn" href="<?php echo e(route('admin.slider.create')); ?>"><i class="fas fa-plus-circle"></i> Add Slider Image</a>
        <a class="quick-btn" href="<?php echo e(route('admin.gallery.create')); ?>"><i class="fas fa-camera"></i> Add Gallery Photo</a>
        <a class="quick-btn" href="<?php echo e(route('admin.upkram.create')); ?>"><i class="fas fa-calendar-plus"></i> Add Upkram</a>
        <a class="quick-btn" href="<?php echo e(route('admin.trusty.create')); ?>"><i class="fas fa-user-plus"></i> Add Trustee</a>
        <a class="quick-btn" href="<?php echo e(route('admin.donorList.create')); ?>"><i class="fas fa-donate"></i> Add Donor</a>
    </div>

    <!-- recent -->
    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="panel-box">
                <h3 class="section-title">Recent Donors</h3>
                <?php if($recentDonors->isNotEmpty()): ?>
                    <table>
                        <thead><tr><th>Name</th><th>Amount</th><th>Date</th></tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $recentDonors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td><?php echo e($d->name); ?></td><td>&#8377; <?php echo e($d->amount); ?></td><td><?php echo e($d->date); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-note">No donors yet.</div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-6 mb-4">
            <div class="panel-box">
                <h3 class="section-title">Recent Feedback</h3>
                <?php if($recentEnquiries->isNotEmpty()): ?>
                    <table>
                        <thead><tr><th>Name</th><th>Mobile</th><th>Message</th></tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $recentEnquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr><td><?php echo e($e->name); ?></td><td><?php echo e($e->mobile); ?></td><td><?php echo e(\Illuminate\Support\Str::limit($e->comment, 40)); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-note">No feedback received yet.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.pages.admin.injector.admin-attribute-injection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\temple\resources\views/layouts/backend/pages/admin/dashboard.blade.php ENDPATH**/ ?>