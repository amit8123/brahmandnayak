<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset("assets/frontend/images/favicon/favicon.ico")); ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset("assets/frontend/images/favicon/favicon.ico")); ?>">
<title>BSSSP | <?php echo $__env->yieldContent('title'); ?></title>
<meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
<meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">


    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="author" content="Tejas Shinde" />
<!-- Styles -->
<!-- partial:partial/__stylesheets.html -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/plugins/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/plugins/animate.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/plugins/magnific-popup.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/plugins/slick.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/plugins/slick-theme.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/plugins/ion.rangeSlider.min.css')); ?>" />

    <!-- Icon Fonts -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/fonts/flaticon/flaticon.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/plugins/font-awesome.min.css')); ?>" />
    <!-- Template Style sheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/responsive.css')); ?>" />
    <!-- Divine theme (animations, polish, responsive) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Mukta:wght@400;600;700&display=swap" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/css/divine.css')); ?>?v=11" />
    <meta name="theme-color" content="#702f1e" />

<!-- /Styles -->
<!-- language select -->


<?php echo $__env->yieldPushContent('styles'); ?>

<?php /**PATH /home4/csismxq9/brahmandnayak.org/resources/views/layouts/frontend/head.blade.php ENDPATH**/ ?>