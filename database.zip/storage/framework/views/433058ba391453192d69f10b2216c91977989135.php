<?php $__env->startSection('sub-title'); ?>
    Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-custom-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-custom-scripts'); ?>
    <script>
        $(document).ready(function(){

            $(".data-table").dataTable()

            /**
             * for showing delete item popup
             */

            $(document).on('click',"#delete-item",function(){
                $(this).addClass('delete-item-trigger-clicked');

                var options = {'backdrop':'static'};
                $('#delete-modal').modal(options)
                $("#delete-modal-label").text('Delete item?')
            })

            // on click of confirmation
            $(document).on('click',"#delete-action-confirm",function(){
                $('.delete-item-trigger-clicked').siblings(".delete-data-form").submit();
            })

            //  on modal hide
            $('#delete-modal').on('hide.bs.modal',function(){
                $('.delete-item-trigger-clicked').removeClass('delete-item-trigger-clicked')
            })
         })
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="main-container container">
        <?php echo $__env->make('layouts.backend.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- heading -->
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <h1 class="text-primary mr-auto">Category</h1>
                </div>
                <div class="col d-flex justify-content-end align-self-center">
                    <a href="<?php echo e(route('admin.GalleryCategory.create')); ?>" class="btn btn-outline-primary pull-right">Create New</a>
                </div>
            </div>
        </div>
        <!-- /heading -->
        <!-- table -->
        <table class="table table-striped table-bordered data-table" cellspacing="0" width="100%">
            <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if($categoryList->isNotEmpty()): ?>
                <?php $__currentLoopData = $categoryList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                    <td class="align-middle"><?php echo e($item->category); ?></td>
                    <td class="align-middle">
                        <a href="<?php echo e(route('admin.GalleryCategory.edit', $item->id)); ?>" class="btn btn-primary"><i
                                class="fa fa-edit"></i> Edit</a>
                        <form method="POST" class="delete-data-form" action="<?php echo e(route('admin.GalleryCategory.delete', $item->id)); ?>"
                            hidden>
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                        </form>
                        <button type="button" class="btn btn-danger" id="delete-item"><i class="fa fa-trash-o"></i>
                            Delete</button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <!-- /table -->
    </div>
    <!-- Delete Modal -->
    <div class="modal fade" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="delete-modal-label" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="delete-modal-label">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="modal-body-content">
                    <h4 class="text-center">Are you sure you want to delete this item?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" id="delete-action-confirm" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
    <!-- /Delete Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.pages.admin.injector.admin-attribute-injection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\temple\resources\views/layouts/backend/pages/admin/gallery-category/index.blade.php ENDPATH**/ ?>